# AI Interview Agent

Adaptive mock-interview platform: generates role-specific questions, scores every answer on a 4-part rubric,
adapts difficulty, produces a final score + readiness prediction + signed PDF certificate, and stores history so
each session is compared with your past performance. Supports **text, voice and video** interviews.

## Architecture (matches the project deck)

| Module | File | What it does |
|---|---|---|
| Question Generator | `interview_agent/question_generator.py` | Claude generates questions from role, level, difficulty, history and optional resume/JD. Offline bank fallback. |
| Answer Analyzer | `answer_analyzer.py` | Scores technical / communication / relevance / depth (0-100), strengths, gaps, feedback. Filler-word and speaking-pace penalties for voice. |
| Decision Engine | `decision_engine.py` | Follow-up vs next question, raises/lowers difficulty, ends interview. |
| Evaluation & Feedback | `evaluator.py` | Weighted overall score, grade, readiness probability + verdict, improvement list. |
| Database / History | `database.py`, `analytics.py` | SQLite: users, sessions, answers. Trend, per-dimension deltas, weak topics, cohort percentile. |
| Voice | `speech.py` | Mic recording in browser -> faster-whisper (local) or OpenAI Whisper API; browser text-to-speech reads questions. |
| Video | `video.py` | OpenCV face presence, framing, eye-contact proxy via WebRTC. Frames are analysed in memory, never saved. |
| Certificate | `certificate.py` | PDF with HMAC-signed ID; verifiable in the app's "Verify certificate" tab. |
| Orchestrator | `agent.py` | Ties it all together; UI-independent (so it is unit-tested). |
| UI | `app.py` | Streamlit. |

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # add ANTHROPIC_API_KEY and a random CERT_SECRET
streamlit run app.py
```

Without an API key the app still runs using a small offline question bank and a keyword/length heuristic scorer
(useful for development; the LLM mode is far more accurate). Voice needs `faster-whisper` (downloads a ~150 MB model on
first use) or `OPENAI_API_KEY`. Video needs `streamlit-webrtc`, `av` and `opencv-python-headless<5`.

## Tests / CI

```bash
pip install pytest && pytest -q
```
GitHub Actions runs the tests on every push (`.github/workflows/ci.yml`).

## Putting it on GitHub

```bash
git init -b main && git add . && git commit -m "Initial commit"
gh repo create ai-interview-agent --private --source=. --push     # or create the repo on github.com and `git remote add origin ...`
```
Never commit `.env` (already in `.gitignore`).

## Honest limitations

- **Readiness prediction** is a transparent heuristic (logistic curve on your score, difficulty reached and consistency), not a model trained on hiring outcomes. Once you collect real outcomes (offers/rejections), train a model on the stored data.
- **Certificate** proves the score came from your platform; it is not an accredited credential.
- **Eye contact** is a proxy (face centred, eyes visible), not gaze or emotion tracking. Consider consent notices and privacy law (e.g. GDPR/India DPDP) before storing real users' answers.
- **No passwords** yet: identity is name+email. Add real auth (e.g. OAuth) before public hosting.
- Streamlit UI and the WebRTC/Whisper paths were not run in the authoring sandbox; core logic is covered by unit tests. Expect small fixes on first run.

## Roadmap ideas
Per-role rubrics and question packs · coding-question sandbox · AI avatar / TTS voice · admin dashboard · Docker + Streamlit Cloud deploy · trained readiness model · multilingual interviews.
