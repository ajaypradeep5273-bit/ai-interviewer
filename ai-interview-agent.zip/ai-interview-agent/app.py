"""Streamlit UI for the AI Interview Agent.  Run:  streamlit run app.py"""
import json

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

from interview_agent import config
from interview_agent.agent import InterviewAgent
from interview_agent.analytics import compare_with_history
from interview_agent.certificate import build_pdf, verify_cert
from interview_agent.database import Database
from interview_agent.llm import LLM
from interview_agent.question_bank import ROLES
from interview_agent.speech import speech_metrics, transcribe
from interview_agent.video import delivery_feedback

st.set_page_config(page_title="AI Interview Agent", page_icon="🎤", layout="wide")


@st.cache_resource
def get_db() -> Database:
    return Database()


@st.cache_resource
def get_llm() -> LLM:
    return LLM()


db, llm = get_db(), get_llm()
ss = st.session_state


def speak(text: str):
    """Read the question aloud with the browser's built-in speech synthesis (no API needed)."""
    safe = json.dumps(text).replace("</", "<\\/")
    components.html(
        f"""<button onclick="s()" style="padding:6px 12px;border-radius:6px;border:1px solid #888;cursor:pointer">
        🔊 Hear question</button>
        <script>function s(){{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance({safe});
        u.rate=0.95;speechSynthesis.speak(u);}}</script>""", height=50)


def read_context(upload) -> str:
    if upload is None:
        return ""
    if upload.name.lower().endswith(".pdf"):
        from pypdf import PdfReader
        return "\n".join((p.extract_text() or "") for p in PdfReader(upload).pages)[:6000]
    return upload.getvalue().decode("utf-8", errors="ignore")[:6000]


# ---------------------------------------------------------------- sidebar: identity
with st.sidebar:
    st.title("🎤 AI Interview Agent")
    st.caption("LLM mode: **" + ("Claude API" if llm.available else "offline rule-based (set ANTHROPIC_API_KEY)") + "**")
    name = st.text_input("Your name", key="name")
    email = st.text_input("Email (used to keep your history)", key="email")
    if name and email and "@" in email:
        ss.user_id = db.get_or_create_user(name, email)
    else:
        ss.pop("user_id", None)
    st.caption("Note: no password yet. Add real authentication before hosting this publicly.")

tab_int, tab_prog, tab_verify = st.tabs(["Interview", "My progress", "Verify certificate"])


# ---------------------------------------------------------------- interview tab
def setup_view():
    st.subheader("Set up your mock interview")
    c1, c2 = st.columns(2)
    with c1:
        pick = st.selectbox("Job role / course", ROLES + ["Other (type below)"])
        custom = st.text_input("Custom role or course (e.g. 'Cloud Engineer', 'MBA Finance')") if pick.startswith("Other") else ""
        level = st.selectbox("Experience level", ["Beginner", "Intermediate", "Advanced"], index=1)
        n = st.slider("Number of main questions", 3, 12, 6)
    with c2:
        mode = st.radio("Answer mode", ["Text", "Voice"], horizontal=True)
        use_video = st.checkbox("Enable video (face/eye-contact analytics, nothing is recorded)", value=False)
        up = st.file_uploader("Optional: resume or job description (PDF/TXT) for tailored questions", type=["pdf", "txt"])
    if st.button("Start interview", type="primary", disabled="user_id" not in ss):
        role = (custom or "").strip() if pick.startswith("Other") else pick
        if not role:
            st.error("Please enter a role."); return
        ss.agent = InterviewAgent(db, ss.user_id, role, level, n, mode.lower(), read_context(up), llm)
        ss.use_video = use_video
        st.rerun()
    if "user_id" not in ss:
        st.info("Enter your name and email in the sidebar to begin.")


def interview_view(ag: InterviewAgent):
    turn = len(ag.history)
    done, total = ag.progress
    st.progress((done - 1) / total, text=f"Question {done} of {total}  ·  {ag.role}  ·  difficulty {ag.current.difficulty}/5")
    if ag.current.is_followup:
        st.caption("Follow-up question")
    st.markdown(f"### {ag.current.text}")
    speak(ag.current.text)

    video_ctx = None
    if ss.get("use_video"):
        try:
            from streamlit_webrtc import webrtc_streamer
            from interview_agent.video import make_processor_class
            video_ctx = webrtc_streamer(key="interview-video", video_processor_factory=make_processor_class(),
                                        media_stream_constraints={"video": True, "audio": False})
        except ImportError:
            st.warning("Install streamlit-webrtc, av and opencv to use video analytics.")

    ans_key, audio_bytes = f"ans_{turn}", None
    if ag.mode == "voice":
        rec = st.audio_input("Record your answer", key=f"aud_{turn}")
        if rec is not None:
            audio_bytes = rec.getvalue()
            if ss.get(f"tx_{turn}") != len(audio_bytes):
                with st.spinner("Transcribing..."):
                    try:
                        ss[ans_key] = transcribe(audio_bytes)
                        ss[f"tx_{turn}"] = len(audio_bytes)
                    except Exception as exc:
                        st.error(f"Transcription failed: {exc}. You can type your answer instead.")
        st.caption("Check the transcript below and fix any mistakes before submitting.")
    answer = st.text_area("Your answer", key=ans_key, height=180)

    c1, c2 = st.columns([1, 1])
    if c1.button("Submit answer", type="primary"):
        vstats = video_ctx.video_processor.stats.pop() if video_ctx and video_ctx.video_processor else None
        sp = speech_metrics(answer, audio_bytes) if audio_bytes else None
        analysis, decision = ag.submit_answer(answer, sp, vstats)
        ss.last_feedback = (analysis, decision, delivery_feedback(vstats))
        st.rerun()
    if c2.button("End interview now"):
        ag.finish(); st.rerun()

    if "last_feedback" in ss:
        a, d, tips = ss.last_feedback
        with st.expander("Feedback on your previous answer", expanded=True):
            st.write(f"**Score {a.overall:.0f}/100**  ·  {d.reason}")
            st.write(a.feedback)
            for s in a.strengths: st.write("✅", s)
            for g in a.gaps: st.write("⚠️", g)
            for t in tips: st.write("🎥", t)


def report_view(ag: InterviewAgent):
    r = ag.report
    st.subheader(f"Interview report: {ag.role}")
    c = st.columns(4)
    c[0].metric("Overall score", f"{r.overall:.0f}/100")
    c[1].metric("Grade", r.grade)
    c[2].metric("Readiness", f"{r.readiness_probability * 100:.0f}%")
    c[3].metric("Questions answered", len(ag.history))
    (st.success if r.readiness_probability >= 0.7 else st.warning if r.readiness_probability >= 0.4 else st.error)(r.verdict)
    st.caption("Readiness is a heuristic estimate from your scores, not a guarantee of hiring outcomes.")
    st.write(r.summary)

    st.markdown("#### Score breakdown")
    for k, (label, _) in config.DIMENSIONS.items():
        st.progress(int(r.dimensions[k]), text=f"{label}: {r.dimensions[k]:.0f}%")
    left, right = st.columns(2)
    with left:
        st.markdown("#### Strengths")
        for s in r.strengths or ["Complete more questions to reveal strengths"]: st.write("✅", s)
    with right:
        st.markdown("#### What to improve")
        for s in r.improvements or ["Great job, keep practising at higher difficulty"]: st.write("🎯", s)
    if any(r.delivery.values()):
        st.markdown("#### Delivery")
        labels = {"filler_per_100": "Filler words / 100", "wpm": "Words per minute",
                  "eye_contact_pct": "Eye contact %", "presence_pct": "In-frame %"}
        cols = st.columns(len(r.delivery))
        for col, (k, v) in zip(cols, r.delivery.items()):
            col.metric(labels.get(k, k), f"{v:.0f}")

    past = [s for s in db.user_sessions(ag.user_id) if s["id"] != ag.session_id]
    cmp = compare_with_history({"overall": r.overall, "dimensions": r.dimensions}, past,
                               db.all_overalls(ag.role))
    st.markdown("#### Compared with your history")
    if cmp["n_previous"] == 0:
        st.write("This is your first completed interview. Take more to unlock trends.")
    else:
        st.write(f"Previous average **{cmp['previous_avg']}**  ·  change vs last **{cmp['delta_vs_last']:+}**"
                 f"  ·  trend **{cmp.get('trend', 'n/a')}**" + ("  ·  🏆 personal best" if cmp["personal_best"] else ""))
        st.write({config.DIMENSIONS[k][0]: f"{v:+}" for k, v in cmp["dimension_delta"].items()})
    if "cohort_percentile" in cmp:
        st.write(f"You scored higher than **{cmp['cohort_percentile']}%** of all {ag.role} sessions.")

    pdf = build_pdf(db.get_session(ag.session_id)["user_name"], ag.role, ag.level, r, ag.cert_id)
    st.download_button("📜 Download score certificate (PDF)", pdf, f"{ag.cert_id}.pdf", "application/pdf")
    st.caption(f"Certificate ID: {ag.cert_id}")
    with st.expander("Full transcript with per-answer scores"):
        for i, h in enumerate(ag.history, 1):
            st.markdown(f"**Q{i}. {h['question']}**  ({h['topic']}, {h['analysis']['overall']:.0f}/100)")
            st.write(h["answer"]); st.write("💬", h["analysis"]["feedback"])
    if st.button("Start a new interview"):
        for k in [k for k in ss if k.startswith(("ans_", "tx_", "aud_"))] + ["agent", "last_feedback"]:
            ss.pop(k, None)
        st.rerun()


with tab_int:
    ag = ss.get("agent")
    if ag is None:
        setup_view()
    elif ag.finished:
        report_view(ag)
    else:
        interview_view(ag)

# ---------------------------------------------------------------- progress tab
with tab_prog:
    if "user_id" not in ss:
        st.info("Enter your name and email in the sidebar.")
    else:
        sess = db.user_sessions(ss.user_id)
        if not sess:
            st.write("No completed interviews yet.")
        else:
            df = pd.DataFrame(sess)
            df["date"] = pd.to_datetime(df["started"], unit="s")
            st.markdown("#### Score over time")
            st.line_chart(df.set_index("date")["overall"])
            st.markdown("#### Weakest topics (all sessions)")
            ts = pd.DataFrame(db.user_topic_stats(ss.user_id))
            st.bar_chart(ts.set_index("topic")["avg_score"])
            st.dataframe(df[["date", "role", "level", "overall", "grade", "readiness", "verdict", "cert_id"]],
                         hide_index=True)

# ---------------------------------------------------------------- verify tab
with tab_verify:
    cid = st.text_input("Certificate ID (e.g. AIA-1A2B3C4D5E6F)")
    if cid:
        row = db.session_by_cert(cid)
        if row and verify_cert(cid, row):
            st.success(f"Valid: {row['user_name']} scored {row['overall']:.0f}/100 ({row['grade']}) for {row['role']}.")
        else:
            st.error("Certificate not found or its data does not match the signature.")
