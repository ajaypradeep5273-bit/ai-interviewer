"""AI Interview Agent: adaptive mock-interview engine."""
__version__ = "0.1.0"
