"""Orchestrates the five modules into one interview session (UI-agnostic, so it is easy to test)."""
from __future__ import annotations
import statistics
from dataclasses import asdict
from typing import Optional

from .answer_analyzer import AnswerAnalyzer, filler_rate
from .certificate import make_cert_id
from .database import Database
from .decision_engine import DecisionEngine, InterviewState
from .evaluator import Evaluator
from .llm import LLM
from .models import Question, AnswerAnalysis, Report
from .question_generator import QuestionGenerator
from . import video as video_mod


class InterviewAgent:
    def __init__(self, db: Database, user_id: int, role: str, level: str = "Intermediate",
                 num_questions: int = 6, mode: str = "text", context: str = "", llm: LLM | None = None):
        llm = llm or LLM()
        self.db, self.user_id, self.role, self.level, self.mode, self.context = db, user_id, role, level, mode, context
        self.gen, self.analyzer, self.engine, self.evaluator = QuestionGenerator(llm), AnswerAnalyzer(llm), DecisionEngine(), Evaluator(llm)
        start_diff = {"Beginner": 2, "Intermediate": 3, "Advanced": 4}.get(level, 3)
        self.state = InterviewState(total_questions=num_questions, difficulty=start_diff)
        self.session_id = db.start_session(user_id, role, level, mode)
        self.history: list[dict] = []
        self.asked: list[str] = []
        self.finished = False
        self.report: Optional[Report] = None
        self.cert_id: Optional[str] = None
        self.current: Question = self._new_question(None)

    def _new_question(self, topic) -> Question:
        q = self.gen.generate(self.role, self.level, self.state.difficulty, topic, self.asked, self.context)
        self.asked.append(q.text)
        return q

    @property
    def progress(self) -> tuple[int, int]:
        return min(self.state.main_answered + (0 if self.finished else 1), self.state.total_questions), self.state.total_questions

    def submit_answer(self, answer: str, speech: dict | None = None, video: dict | None = None):
        """Returns (analysis, decision). Advances to the next question unless the interview ended."""
        if self.finished:
            raise RuntimeError("Interview already finished")
        q = self.current
        analysis = self.analyzer.analyze(q, answer, self.role, speech)
        delivery = {"filler_per_100": filler_rate(answer), **{k: v for k, v in (speech or {}).items() if v is not None},
                    **{f"video_{k}": v for k, v in (video or {}).items()}}
        self.db.save_answer(self.session_id, len(self.history) + 1, q, answer, analysis.to_dict(), delivery)
        self.history.append({"question": q.text, "topic": q.topic, "difficulty": q.difficulty, "answer": answer,
                             "analysis": analysis.to_dict(), "delivery": delivery})
        decision = self.engine.decide(self.state, q, analysis)
        if decision.action == "followup":
            self.current = self.gen.followup(self.role, q, answer, analysis)
            self.asked.append(self.current.text)
        elif decision.action == "next":
            self.current = self._new_question(decision.topic)
        else:
            self.finish()
        return analysis, decision

    def _delivery_summary(self) -> dict:
        def avg(key):
            vals = [h["delivery"][key] for h in self.history if h["delivery"].get(key) is not None]
            return statistics.mean(vals) if vals else None
        return {"filler_per_100": avg("filler_per_100"), "wpm": avg("wpm"), "eye_contact_pct": avg("video_eye_contact"),
                "presence_pct": avg("video_presence")}

    def finish(self) -> Report:
        if self.report:
            return self.report
        self.finished = True
        self.report = self.evaluator.build_report(self.role, self.level, self.history, self.state.difficulty,
                                                  self._delivery_summary())
        self.cert_id = make_cert_id(self.session_id, self.user_id, self.role, self.report.overall)
        self.db.finish_session(self.session_id, self.report, self.cert_id)
        return self.report
