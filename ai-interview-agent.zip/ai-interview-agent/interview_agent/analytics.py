"""Compare the current session with the user's history and the wider cohort."""
from __future__ import annotations
import statistics

from . import config


def compare_with_history(current: dict, past_sessions: list[dict], cohort_overalls: list[float] | None = None) -> dict:
    """current = {"overall": x, "dimensions": {...}}; past_sessions = finished earlier sessions (rows with report_json)."""
    import json
    out: dict = {"n_previous": len(past_sessions)}
    prev_overalls = [s["overall"] for s in past_sessions if s.get("overall") is not None]
    if prev_overalls:
        out["previous_avg"] = round(statistics.mean(prev_overalls), 1)
        out["delta_vs_avg"] = round(current["overall"] - out["previous_avg"], 1)
        out["delta_vs_last"] = round(current["overall"] - prev_overalls[-1], 1)
        out["personal_best"] = current["overall"] >= max(prev_overalls)
        if len(prev_overalls) >= 2:
            xs = list(range(len(prev_overalls) + 1))
            ys = prev_overalls + [current["overall"]]
            mx, my = statistics.mean(xs), statistics.mean(ys)
            slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)
            out["trend"] = "improving" if slope > 1 else "declining" if slope < -1 else "flat"
    dim_delta = {}
    for k in config.DIMENSIONS:
        vals = []
        for s in past_sessions:
            try:
                vals.append(json.loads(s["report_json"])["dimensions"][k])
            except (KeyError, TypeError, ValueError):
                pass
        if vals:
            dim_delta[k] = round(current["dimensions"][k] - statistics.mean(vals), 1)
    out["dimension_delta"] = dim_delta
    if cohort_overalls and len(cohort_overalls) >= 5:
        below = sum(1 for x in cohort_overalls if x < current["overall"])
        out["cohort_percentile"] = round(100 * below / len(cohort_overalls))
    return out
