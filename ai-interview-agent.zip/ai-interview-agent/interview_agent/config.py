import os
from pathlib import Path

try:  # optional
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # pragma: no cover
    pass

ROOT = Path(__file__).resolve().parent.parent
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
CERT_SECRET = os.getenv("CERT_SECRET", "change-me")
DB_PATH = os.getenv("DB_PATH", str(ROOT / "data" / "interviews.db"))

# Scoring rubric (matches the "Evaluation Dashboard" slide). Weights sum to 1.
DIMENSIONS = {
    "technical": ("Technical Knowledge & Accuracy", 0.35),
    "communication": ("Communication & Articulation", 0.20),
    "relevance": ("Response Relevance & Structure", 0.20),
    "depth": ("Problem Solving & Depth", 0.25),
}
