"""Module 5: Database / History (SQLite)."""
from __future__ import annotations
import json
import sqlite3
import time
from contextlib import contextmanager

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
  role TEXT NOT NULL, level TEXT NOT NULL, mode TEXT NOT NULL, started REAL NOT NULL, finished REAL,
  overall REAL, grade TEXT, readiness REAL, verdict TEXT, report_json TEXT, cert_id TEXT);
CREATE TABLE IF NOT EXISTS answers(
  id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL REFERENCES sessions(id),
  seq INTEGER NOT NULL, topic TEXT, difficulty INTEGER, is_followup INTEGER, question TEXT, answer TEXT,
  technical REAL, communication REAL, relevance REAL, depth REAL, overall REAL,
  analysis_json TEXT, delivery_json TEXT);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_answers_session ON answers(session_id);
"""


class Database:
    def __init__(self, path: str | None = None):
        self.path = path or config.DB_PATH
        if self.path != ":memory:":
            import os
            os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        self._mem = sqlite3.connect(":memory:") if self.path == ":memory:" else None
        with self._conn() as c:
            c.executescript(SCHEMA)

    @contextmanager
    def _conn(self):
        conn = self._mem or sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            if self._mem is None:
                conn.close()

    # ---- users
    def get_or_create_user(self, name: str, email: str) -> int:
        email = email.strip().lower()
        with self._conn() as c:
            row = c.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
            if row:
                return row["id"]
            return c.execute("INSERT INTO users(name,email,created) VALUES(?,?,?)",
                             (name.strip(), email, time.time())).lastrowid

    # ---- sessions
    def start_session(self, user_id: int, role: str, level: str, mode: str) -> int:
        with self._conn() as c:
            return c.execute("INSERT INTO sessions(user_id,role,level,mode,started) VALUES(?,?,?,?,?)",
                             (user_id, role, level, mode, time.time())).lastrowid

    def save_answer(self, session_id: int, seq: int, q, answer: str, analysis: dict, delivery: dict | None):
        with self._conn() as c:
            c.execute(
                "INSERT INTO answers(session_id,seq,topic,difficulty,is_followup,question,answer,technical,"
                "communication,relevance,depth,overall,analysis_json,delivery_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (session_id, seq, q.topic, q.difficulty, int(q.is_followup), q.text, answer, analysis["technical"],
                 analysis["communication"], analysis["relevance"], analysis["depth"], analysis["overall"],
                 json.dumps(analysis), json.dumps(delivery or {})))

    def finish_session(self, session_id: int, report, cert_id: str):
        from dataclasses import asdict
        with self._conn() as c:
            c.execute("UPDATE sessions SET finished=?, overall=?, grade=?, readiness=?, verdict=?, report_json=?, cert_id=? WHERE id=?",
                      (time.time(), report.overall, report.grade, report.readiness_probability, report.verdict,
                       json.dumps(asdict(report)), cert_id, session_id))

    # ---- queries
    def get_session(self, session_id: int) -> dict | None:
        with self._conn() as c:
            r = c.execute("SELECT s.*, u.name AS user_name FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=?",
                          (session_id,)).fetchone()
            return dict(r) if r else None

    def session_by_cert(self, cert_id: str) -> dict | None:
        with self._conn() as c:
            r = c.execute("SELECT s.*, u.name AS user_name FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.cert_id=?",
                          ((cert_id or "").strip().upper(),)).fetchone()
            return dict(r) if r else None

    def user_sessions(self, user_id: int, finished_only: bool = True) -> list[dict]:
        q = "SELECT * FROM sessions WHERE user_id=?" + (" AND finished IS NOT NULL" if finished_only else "") + " ORDER BY started"
        with self._conn() as c:
            return [dict(r) for r in c.execute(q, (user_id,))]

    def session_answers(self, session_id: int) -> list[dict]:
        with self._conn() as c:
            return [dict(r) for r in c.execute("SELECT * FROM answers WHERE session_id=? ORDER BY seq", (session_id,))]

    def user_topic_stats(self, user_id: int) -> list[dict]:
        with self._conn() as c:
            return [dict(r) for r in c.execute(
                "SELECT a.topic, AVG(a.overall) AS avg_score, COUNT(*) AS n FROM answers a JOIN sessions s ON s.id=a.session_id "
                "WHERE s.user_id=? AND s.finished IS NOT NULL GROUP BY a.topic ORDER BY avg_score", (user_id,))]

    def all_overalls(self, role: str | None = None) -> list[float]:
        q = "SELECT overall FROM sessions WHERE finished IS NOT NULL" + (" AND role=?" if role else "")
        with self._conn() as c:
            return [r["overall"] for r in c.execute(q, (role,) if role else ())]
