"""Module 3: Decision Engine. Chooses follow-up vs next question, difficulty and topic."""
from __future__ import annotations
from dataclasses import dataclass, field

from .models import AnswerAnalysis, Decision, Question


@dataclass
class InterviewState:
    total_questions: int
    difficulty: int = 3
    main_answered: int = 0                         # follow-ups don't count toward the total
    followups_on_current: int = 0
    topic_scores: dict[str, list[float]] = field(default_factory=dict)
    weak_topics: list[str] = field(default_factory=list)


class DecisionEngine:
    HIGH, LOW = 75.0, 45.0

    def decide(self, state: InterviewState, question: Question, analysis: AnswerAnalysis) -> Decision:
        state.topic_scores.setdefault(question.topic, []).append(analysis.overall)
        if not question.is_followup:
            state.main_answered += 1
            state.followups_on_current = 0
        else:
            state.followups_on_current += 1

        if analysis.overall < self.LOW and question.topic not in state.weak_topics:
            state.weak_topics.append(question.topic)

        # Probe once if the answer was partial.
        if (analysis.followup_needed and state.followups_on_current == 0 and not question.is_followup
                and state.main_answered < state.total_questions):
            return Decision("followup", state.difficulty, question.topic, "Partial answer: probing deeper")

        if state.main_answered >= state.total_questions:
            return Decision("end", state.difficulty, None, "All planned questions answered")

        if analysis.overall >= self.HIGH:
            state.difficulty = min(5, state.difficulty + 1)
            reason = "Strong answer: raising difficulty"
        elif analysis.overall < self.LOW:
            state.difficulty = max(1, state.difficulty - 1)
            reason = "Weak answer: easing difficulty"
        else:
            reason = "Adequate answer: keeping difficulty"

        return Decision("next", state.difficulty, None, reason)
