"""Module 4: Evaluation & Feedback. Aggregates answers into a final report and a readiness prediction."""
from __future__ import annotations
import math
import statistics
from collections import Counter

from . import config
from .llm import LLM
from .models import Report

SYSTEM = "You are a career coach writing concise, honest interview feedback. Reply with JSON only."


def grade_for(score: float) -> str:
    for cut, g in [(90, "A+"), (80, "A"), (70, "B"), (60, "C"), (50, "D")]:
        if score >= cut:
            return g
    return "F"


def predict_readiness(overall: float, consistency_std: float, final_difficulty: int) -> tuple[float, str]:
    """Heuristic probability (0-1) that the candidate would clear a real interview for this role.

    It is a transparent scoring rule, NOT a trained model: score, adjusted up for finishing at higher
    difficulty and down for inconsistent answers, squashed through a logistic curve centred at 65.
    Replace with a model trained on real outcomes once you have labelled data.
    """
    adjusted = overall + 2.0 * (final_difficulty - 3) - 0.3 * consistency_std
    prob = 1 / (1 + math.exp(-(adjusted - 65) / 8))
    if prob >= 0.70:
        verdict = "Likely to clear the interview"
    elif prob >= 0.40:
        verdict = "Borderline: more practice recommended"
    else:
        verdict = "Not ready yet: significant improvement needed"
    return round(prob, 3), verdict


class Evaluator:
    def __init__(self, llm: LLM | None = None):
        self.llm = llm or LLM()

    def build_report(self, role: str, level: str, answers: list[dict], final_difficulty: int,
                     delivery: dict | None = None) -> Report:
        answers = [a for a in answers if a.get("analysis")]
        if not answers:
            return Report(0, {k: 0 for k in config.DIMENSIONS}, "F", 0.0, "No answers recorded",
                          "No answers were recorded.", ["Complete at least one question."], [], {})
        dims = {k: round(statistics.mean(a["analysis"][k] for a in answers), 1) for k in config.DIMENSIONS}
        overall = round(sum(dims[k] * w for k, (_, w) in config.DIMENSIONS.items()), 1)
        overalls = [a["analysis"]["overall"] for a in answers]
        std = statistics.pstdev(overalls) if len(overalls) > 1 else 0.0

        by_topic: dict[str, list[float]] = {}
        for a in answers:
            by_topic.setdefault(a["topic"], []).append(a["analysis"]["overall"])
        topic_scores = {t: round(statistics.mean(v), 1) for t, v in by_topic.items()}

        prob, verdict = predict_readiness(overall, std, final_difficulty)
        strengths = [s for s, _ in Counter(s for a in answers for s in a["analysis"].get("strengths", [])).most_common(4)]
        gaps = [g for g, _ in Counter(g for a in answers for g in a["analysis"].get("gaps", [])).most_common(5)]

        improvements = []
        for k in sorted(dims, key=dims.get)[:2]:
            if dims[k] < 75:
                improvements.append(f"Improve {config.DIMENSIONS[k][0]} (currently {dims[k]:.0f}/100)")
        improvements += [f"Review topic: {t} ({s:.0f}/100)" for t, s in sorted(topic_scores.items(), key=lambda x: x[1])[:2] if s < 65]
        improvements += gaps[:3]

        summary = self._summary(role, level, overall, verdict, dims, topic_scores, gaps)
        deliv = {k: round(v, 1) for k, v in (delivery or {}).items() if v is not None}
        return Report(overall, dims, grade_for(overall), prob, verdict, summary,
                      improvements[:7], strengths, topic_scores, deliv)

    def _summary(self, role, level, overall, verdict, dims, topics, gaps) -> str:
        prompt = (f"Role: {role} ({level}). Overall {overall}/100. Verdict: {verdict}. Dimension scores: {dims}. "
                  f"Topic scores: {topics}. Frequent gaps: {gaps[:5]}.\n"
                  'Write a 3-4 sentence honest summary of the performance. JSON: {"summary": str}')
        d = self.llm.json(SYSTEM, prompt, 400)
        if d and isinstance(d.get("summary"), str) and d["summary"].strip():
            return d["summary"].strip()
        best = max(dims, key=dims.get); worst = min(dims, key=dims.get)
        return (f"You scored {overall:.0f}/100 for the {role} interview. Your strongest area was "
                f"{config.DIMENSIONS[best][0]} ({dims[best]:.0f}) and the weakest was "
                f"{config.DIMENSIONS[worst][0]} ({dims[worst]:.0f}). {verdict}.")
