"""Thin wrapper around the Anthropic API that returns parsed JSON.

If no API key is configured (or a call fails) every method returns None so callers can
fall back to the offline rule-based logic. This keeps the app usable and testable offline.
"""
from __future__ import annotations
import json
import logging
from typing import Optional

from . import config

log = logging.getLogger(__name__)


def extract_json(text: str) -> Optional[dict]:
    """Pull the first JSON object out of a model reply (tolerates code fences / prose)."""
    if not text:
        return None
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end <= start:
        return None
    try:
        return json.loads(text[start:end + 1])
    except json.JSONDecodeError:
        return None


class LLM:
    def __init__(self, api_key: str | None = None, model: str | None = None, client=None):
        self.api_key = api_key if api_key is not None else config.ANTHROPIC_API_KEY
        self.model = model or config.ANTHROPIC_MODEL
        self._client = client

    @property
    def available(self) -> bool:
        return self._client is not None or bool(self.api_key)

    def _get_client(self):
        if self._client is None:
            import anthropic  # lazy import so the package is optional offline
            self._client = anthropic.Anthropic(api_key=self.api_key)
        return self._client

    def complete(self, system: str, prompt: str, max_tokens: int = 1200) -> Optional[str]:
        if not self.available:
            return None
        try:
            resp = self._get_client().messages.create(
                model=self.model, max_tokens=max_tokens, system=system,
                messages=[{"role": "user", "content": prompt}],
            )
            return "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
        except Exception as exc:  # network, auth, rate limit...
            log.warning("LLM call failed: %s", exc)
            return None

    def json(self, system: str, prompt: str, max_tokens: int = 1200) -> Optional[dict]:
        return extract_json(self.complete(system, prompt, max_tokens) or "")
