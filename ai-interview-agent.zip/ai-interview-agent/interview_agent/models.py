from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Optional


@dataclass
class Question:
    text: str
    topic: str
    difficulty: int = 3              # 1 (easy) .. 5 (hard)
    is_followup: bool = False
    keywords: list[str] = field(default_factory=list)  # expected concepts (used by offline analyzer)


@dataclass
class AnswerAnalysis:
    technical: float
    communication: float
    relevance: float
    depth: float
    overall: float
    strengths: list[str] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    feedback: str = ""
    followup_needed: bool = False
    followup_hint: str = ""
    source: str = "llm"              # "llm" or "offline"

    def dims(self) -> dict[str, float]:
        return {"technical": self.technical, "communication": self.communication,
                "relevance": self.relevance, "depth": self.depth}

    def to_dict(self):
        return asdict(self)


@dataclass
class Decision:
    action: str                      # "followup" | "next" | "end"
    difficulty: int
    topic: Optional[str] = None
    reason: str = ""


@dataclass
class Report:
    overall: float
    dimensions: dict[str, float]
    grade: str
    readiness_probability: float
    verdict: str
    summary: str
    improvements: list[str]
    strengths: list[str]
    topic_scores: dict[str, float]
    delivery: dict[str, float] = field(default_factory=dict)
