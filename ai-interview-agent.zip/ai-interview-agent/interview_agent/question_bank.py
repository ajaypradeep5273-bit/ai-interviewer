"""Offline question bank used when no LLM is available. Each item: (topic, difficulty, question, keywords)."""

BANK = {
    "Software Engineer": [
        ("Data Structures", 1, "What is the difference between an array and a linked list?",
         ["contiguous", "index", "pointer", "insertion", "o(1)", "o(n)"]),
        ("Data Structures", 3, "How does a hash table work, and how are collisions handled?",
         ["hash function", "bucket", "chaining", "open addressing", "load factor", "o(1)"]),
        ("Algorithms", 3, "Explain the time complexity of quicksort and when it performs badly.",
         ["pivot", "o(n log n)", "o(n^2)", "worst case", "sorted", "partition"]),
        ("System Design", 4, "How would you design a URL shortener that handles millions of requests per day?",
         ["hash", "database", "cache", "scal", "collision", "redirect", "load balancer"]),
        ("OOP", 2, "Explain polymorphism and give a real example.",
         ["override", "interface", "inheritance", "runtime", "method", "abstract"]),
        ("Databases", 3, "What is the difference between SQL and NoSQL, and when would you pick each?",
         ["schema", "acid", "join", "scal", "document", "consistency"]),
        ("Concurrency", 4, "What is a race condition and how do you prevent it?",
         ["thread", "lock", "mutex", "atomic", "shared", "synchron"]),
        ("Behavioral", 2, "Tell me about a time you debugged a difficult problem. What was your approach?",
         ["situation", "root cause", "result", "learned", "team", "fix"]),
    ],
    "Data Scientist": [
        ("Statistics", 2, "Explain the bias-variance trade-off.",
         ["overfit", "underfit", "complexity", "generaliz", "regulariz", "training", "test"]),
        ("Machine Learning", 3, "How do you handle an imbalanced classification dataset?",
         ["resampl", "smote", "class weight", "precision", "recall", "f1", "auc"]),
        ("Machine Learning", 3, "Compare random forests and gradient boosting.",
         ["bagging", "boosting", "tree", "variance", "bias", "sequential", "overfit"]),
        ("Statistics", 3, "What is a p-value and what are its common misinterpretations?",
         ["null hypothesis", "probability", "significan", "0.05", "effect size"]),
        ("Data Engineering", 2, "How do you deal with missing data?",
         ["impute", "mean", "median", "drop", "missing", "bias", "indicator"]),
        ("Evaluation", 4, "How would you validate a model before deploying it to production?",
         ["cross-validation", "holdout", "drift", "monitor", "metric", "a/b", "baseline"]),
    ],
    "Web Developer": [
        ("JavaScript", 2, "Explain closures in JavaScript with an example.",
         ["scope", "function", "variable", "lexical", "private", "outer"]),
        ("Web Fundamentals", 2, "What happens when you type a URL into the browser and press Enter?",
         ["dns", "tcp", "http", "server", "render", "html", "tls"]),
        ("Frontend", 3, "How would you improve the performance of a slow web page?",
         ["lazy", "cache", "minif", "bundle", "image", "cdn", "lighthouse"]),
        ("Security", 3, "What are XSS and CSRF, and how do you defend against them?",
         ["escape", "sanitiz", "token", "cookie", "samesite", "csp", "script"]),
        ("APIs", 3, "What makes an API RESTful? Compare it with GraphQL.",
         ["resource", "stateless", "verb", "http", "query", "over-fetch", "endpoint"]),
    ],
    "HR / Behavioral": [
        ("Behavioral", 1, "Tell me about yourself and why you are interested in this role.",
         ["experience", "skill", "motivat", "goal", "role", "company"]),
        ("Behavioral", 2, "Describe a conflict with a teammate and how you resolved it.",
         ["situation", "listen", "compromise", "result", "communicat", "outcome"]),
        ("Behavioral", 3, "Tell me about a failure and what you learned from it.",
         ["mistake", "learn", "responsib", "improve", "action", "result"]),
        ("Leadership", 3, "Describe a time you led a project or took initiative.",
         ["lead", "plan", "delegat", "team", "result", "initiative"]),
        ("Behavioral", 2, "Where do you see yourself in five years?",
         ["grow", "goal", "skill", "contribut", "learn"]),
    ],
}

GENERIC = [
    ("Fundamentals", 1, "Explain the core fundamentals of {role} to someone new to the field.", []),
    ("Fundamentals", 2, "What are the most important tools and technologies you use as a {role}, and why?", []),
    ("Problem Solving", 3, "Walk me through how you would approach a hard, unfamiliar problem as a {role}.", []),
    ("Experience", 3, "Describe the most challenging {role} project you have worked on and your specific contribution.", []),
    ("Best Practices", 4, "What are common mistakes made by {role}s, and how do you avoid them?", []),
    ("Scenario", 4, "A critical issue appears in production and stakeholders are waiting. How do you handle it as a {role}?", []),
    ("Growth", 2, "How do you keep your skills current as a {role}?", []),
]


def items_for(role: str):
    for name, items in BANK.items():
        if name.lower() == role.lower():
            return items
    return [(t, d, q.format(role=role), k) for t, d, q, k in GENERIC]


ROLES = list(BANK.keys())
