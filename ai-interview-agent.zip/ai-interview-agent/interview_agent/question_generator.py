"""Module 1: Question Generator (LLM first, rule-based offline fallback)."""
from __future__ import annotations
import random
from typing import Optional

from .llm import LLM
from .models import Question, AnswerAnalysis
from . import question_bank

SYSTEM = (
    "You are an experienced, professional interviewer. You ask ONE clear interview question at a time. "
    "Reply with JSON only."
)


class QuestionGenerator:
    def __init__(self, llm: LLM | None = None, rng: random.Random | None = None):
        self.llm = llm or LLM()
        self.rng = rng or random.Random()

    def generate(self, role: str, level: str, difficulty: int, topic: Optional[str],
                 asked: list[str], context: str = "") -> Question:
        """context = resume / job description text (optional)."""
        q = self._llm_question(role, level, difficulty, topic, asked, context)
        return q or self._offline_question(role, difficulty, topic, asked)

    def followup(self, role: str, question: Question, answer: str, analysis: AnswerAnalysis) -> Question:
        prompt = (
            f"Role: {role}\nOriginal question: {question.text}\nCandidate answer: {answer[:2000]}\n"
            f"Gaps noticed: {analysis.gaps}\nHint: {analysis.followup_hint}\n\n"
            'Ask ONE short follow-up that probes the weakest part of the answer. '
            'JSON: {"question": str}'
        )
        data = self.llm.json(SYSTEM, prompt, 300)
        if data and isinstance(data.get("question"), str) and data["question"].strip():
            return Question(data["question"].strip(), question.topic, question.difficulty, True)
        gap = analysis.gaps[0] if analysis.gaps else "the key details"
        return Question(f"Can you go deeper on {gap}? Please give a concrete example.",
                        question.topic, question.difficulty, True)

    def _llm_question(self, role, level, difficulty, topic, asked, context) -> Optional[Question]:
        if not self.llm.available:
            return None
        prompt = (
            f"Role/course: {role}\nCandidate level: {level}\nTarget difficulty (1-5): {difficulty}\n"
            f"Preferred topic: {topic or 'your choice, vary the topics'}\n"
            f"Already asked (do not repeat): {asked[-10:]}\n"
            f"Candidate resume / job description (may be empty):\n{context[:3000]}\n\n"
            'JSON: {"question": str, "topic": str, "difficulty": int, "keywords": [expected key concepts]}'
        )
        d = self.llm.json(SYSTEM, prompt, 500)
        if not d or not isinstance(d.get("question"), str) or not d["question"].strip():
            return None
        try:
            diff = max(1, min(5, int(d.get("difficulty", difficulty))))
        except (TypeError, ValueError):
            diff = difficulty
        kws = [str(k) for k in d.get("keywords", []) if isinstance(k, (str, int))][:10]
        return Question(d["question"].strip(), str(d.get("topic") or topic or role), diff, False, kws)

    def _offline_question(self, role, difficulty, topic, asked) -> Question:
        items = [i for i in question_bank.items_for(role) if i[2] not in asked]
        if not items:  # bank exhausted: allow repeats rather than crash
            items = question_bank.items_for(role)
        if topic:
            same = [i for i in items if i[0] == topic]
            items = same or items
        items.sort(key=lambda i: (abs(i[1] - difficulty), self.rng.random()))
        t, d, text, kws = items[0]
        return Question(text, t, d, False, list(kws))
