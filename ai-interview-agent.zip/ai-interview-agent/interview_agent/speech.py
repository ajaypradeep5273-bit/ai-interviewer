"""Voice answers: speech-to-text + delivery metrics. Text-to-speech runs in the browser (see app.py)."""
from __future__ import annotations
import io
import tempfile
import wave

from . import config


def wav_duration(audio_bytes: bytes) -> float | None:
    try:
        with wave.open(io.BytesIO(audio_bytes)) as w:
            return w.getnframes() / float(w.getframerate())
    except Exception:
        return None


def speech_metrics(transcript: str, audio_bytes: bytes | None) -> dict:
    dur = wav_duration(audio_bytes) if audio_bytes else None
    n = len(transcript.split())
    return {"duration_s": dur, "wpm": (n / (dur / 60)) if dur and dur > 2 else None}


_whisper_model = None


def transcribe(audio_bytes: bytes, language: str | None = "en") -> str:
    """Try local faster-whisper first, then the OpenAI Whisper API. Raises RuntimeError if neither works."""
    global _whisper_model
    try:
        from faster_whisper import WhisperModel
        if _whisper_model is None:
            _whisper_model = WhisperModel("base", device="cpu", compute_type="int8")
        with tempfile.NamedTemporaryFile(suffix=".wav") as f:
            f.write(audio_bytes); f.flush()
            segs, _ = _whisper_model.transcribe(f.name, language=language, vad_filter=True)
            return " ".join(s.text.strip() for s in segs).strip()
    except ImportError:
        pass
    if config.OPENAI_API_KEY:
        import requests
        r = requests.post("https://api.openai.com/v1/audio/transcriptions",
                          headers={"Authorization": f"Bearer {config.OPENAI_API_KEY}"},
                          files={"file": ("answer.wav", audio_bytes, "audio/wav")},
                          data={"model": "whisper-1"}, timeout=60)
        r.raise_for_status()
        return r.json().get("text", "").strip()
    raise RuntimeError("No speech-to-text backend: install faster-whisper or set OPENAI_API_KEY.")
