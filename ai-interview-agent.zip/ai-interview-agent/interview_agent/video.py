"""Video interview analytics: face presence, framing and a rough eye-contact proxy.

Uses OpenCV Haar cascades (fast, CPU only). These are crude signals: "eye contact" here means a face
is detected, roughly centred, with eyes visible, i.e. facing the camera. It does not track gaze or emotion.
Frames are analysed in memory and never stored.
"""
from __future__ import annotations
import threading


class FaceTracker:
    def __init__(self):
        import cv2
        self.cv2 = cv2
        self.face = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        self.eyes = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_eye.xml")

    def analyze_frame(self, bgr) -> dict:
        """Returns {"present": bool, "centered": bool, "eye_contact": bool} for one BGR frame."""
        cv2 = self.cv2
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape[:2]
        faces = self.face.detectMultiScale(gray, 1.2, 5, minSize=(max(40, w // 10), max(40, h // 10)))
        if len(faces) == 0:
            return {"present": False, "centered": False, "eye_contact": False}
        x, y, fw, fh = max(faces, key=lambda f: f[2] * f[3])
        cx, cy = x + fw / 2, y + fh / 2
        centered = abs(cx - w / 2) < 0.2 * w and abs(cy - h / 2) < 0.25 * h
        roi = gray[y:y + fh // 2 + fh // 8, x:x + fw]
        eyes = self.eyes.detectMultiScale(roi, 1.1, 4, minSize=(fw // 10, fw // 10))
        return {"present": True, "centered": bool(centered), "eye_contact": bool(centered and len(eyes) >= 1)}


class VideoStats:
    """Thread-safe accumulator; call pop() at the end of each answer to get and reset per-answer metrics."""

    def __init__(self):
        self._lock = threading.Lock()
        self._reset()

    def _reset(self):
        self.n = self.present = self.centered = self.eye = 0

    def add(self, r: dict):
        with self._lock:
            self.n += 1
            self.present += r["present"]; self.centered += r["centered"]; self.eye += r["eye_contact"]

    def pop(self) -> dict | None:
        with self._lock:
            if self.n == 0:
                return None
            out = {"presence": 100 * self.present / self.n, "framing": 100 * self.centered / self.n,
                   "eye_contact": 100 * self.eye / self.n, "frames": self.n}
            self._reset()
            return out


def make_processor_class():
    """Builds the streamlit-webrtc processor lazily so the package stays optional."""
    import av
    from streamlit_webrtc import VideoProcessorBase

    class Processor(VideoProcessorBase):
        def __init__(self):
            self.tracker = FaceTracker()
            self.stats = VideoStats()
            self._i = 0

        def recv(self, frame):
            img = frame.to_ndarray(format="bgr24")
            self._i += 1
            if self._i % 5 == 0:  # analyse ~every 5th frame to keep latency low
                self.stats.add(self.tracker.analyze_frame(img))
            return av.VideoFrame.from_ndarray(img, format="bgr24")

    return Processor


def delivery_feedback(v: dict | None) -> list[str]:
    if not v:
        return []
    tips = []
    if v["presence"] < 80:
        tips.append("Stay in frame while answering")
    if v["framing"] < 60:
        tips.append("Centre your face in the camera")
    if v["eye_contact"] < 50:
        tips.append("Look towards the camera more often")
    return tips
